from django.shortcuts import render
from django.http import HttpResponse
from .models import Student
from django.db.models import Avg, Max


# Create your views here.
def home(request):
    data = Student.objects.all()
    return render(request, 'page.html', {'data': data})

def toppers(request):
    data = Student.objects.all()
    maths_top = Student.objects.order_by('-maths').first()
    
    physics_top = Student.objects.order_by('-physics').first()
    
    chemistry_top = Student.objects.order_by('-chemistry').first()

    topper = None
    highest_avg = 0

    for s in data:
        total = s.maths + s.physics + s.chemistry
        avg = total / 3
        if avg > highest_avg:
            highest_avg = avg
            topper = s

    toppers_data = {
        'maths_top': maths_top,
        'physics_top': physics_top,
        'chemistry_top': chemistry_top,
        'overall_topper': topper,
        'highest_avg': highest_avg,
    }

    return render(request, 'data.html', toppers_data)

def average(request):
    subject_averages = Student.objects.aggregate(
        avg_maths=Avg('maths'),
        avg_physics=Avg('physics'),
        avg_chemistry=Avg('chemistry')
    )
    return render(request, 'data2.html', {'averages': subject_averages})

def search_student(request):
    student = None
    wuery = ""
    total = None
    average = None

    if request.method == "POST":
        query = request.POST.get("search_student", "").strip()
    else:
        query = request.POST.get("q", "").strip()

    if query:
        try:
            student = Student.objects.get(student_name=query)
        except Student.DoesNotExist:

            student = Student.objects.filter(student_name = query)

    if student:
        total = (student.maths or 0) + (student.physics or 0) + (student.chemistry or 0)
        average = round(total/3.0, 2)

    return render(request, 'search_student.html', {
        "student":student,
        'query': query,
        'total': total,
        'average': average,
    })



