from django.contrib import admin
from .models import Student


class StudentAdmin(admin.ModelAdmin):
    list_display = ('regno', 'student_name', 'branch', 'physics', 'chemistry', 'maths')
    search_fields = ('student_name',)
    list_filter = ('branch',)
   

# Register your models here.
admin.site.register(Student, StudentAdmin)

